zip aurora-web-us-east-1.zip -r * . 
aws s3 cp aurora-web-us-east-1.zip s3://haimtran-workspace/